'use strict'
const merge = require('webpack-merge')
const prodEnv = require('./prod.env')

module.exports = merge(prodEnv, {
  NODE_ENV: '"development"',
  APIS:'"http://10.4.2.163:8082/peiyou-pad-mgmt/"'
})
